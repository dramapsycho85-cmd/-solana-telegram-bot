# Telegram Solana Microcap AutoTrader

Diese erste Version handelt ausschließlich mit virtuellem Geld (Paper Trading).

## Einrichtung
1. Bei Telegram BotFather einen Bot erstellen und den Token kopieren.
2. `.env.example` in `.env` umbenennen.
3. `TELEGRAM_BOT_TOKEN` eintragen. Seed Phrase/Private Key niemals eintragen.
4. Python 3.11+ installieren.
5. Im Projektordner:
   `pip install -r requirements.txt`
   `python bot.py`
6. In Telegram `/start`, danach `/run`.

Der Bot scannt einmal pro Minute über öffentliche DexScreener-Daten nach Solana-Tokens mit ca. $5K-$50K MC, Mindestliquidität und kurzfristiger Kaufaktivität. Er eröffnet maximal drei simulierte $5-Positionen und verwaltet einen -20%-Stop sowie einen Trailing Exit nach deutlichem Anstieg.

Wichtig: DexScreener Token Profiles ist kein vollständiger Firehose aller neu gestarteten Tokens. Diese Version ist zum Testen der Strategie gedacht. Erst wenn genügend Paper-Trades ausgewertet wurden, sollte überhaupt über Echtgeld-Ausführung nachgedacht werden.
